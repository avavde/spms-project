import React from 'react';

const SystemPerformance = () => {
  return (
    <div>
      <p>Состояние системы: Нормально</p>
      <ul>
        <li>Активные терминалы: 10</li>
        <li>Среднее время отклика: 200 мс</li>
      </ul>
    </div>
  );
};

export default SystemPerformance;
