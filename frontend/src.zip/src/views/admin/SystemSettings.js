import React from 'react';
import { CCard, CCardBody, CCardHeader, CCol, CRow } from '@coreui/react';

const SystemSettings = () => {
  return (
    <CRow>
      <CCol xs="12">
        <CCard>
          <CCardHeader>
            Настройки системы
          </CCardHeader>
          <CCardBody>
            {/* Добавьте функционал для настроек системы */}
            Настройки системы.
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  );
};

export default SystemSettings;
